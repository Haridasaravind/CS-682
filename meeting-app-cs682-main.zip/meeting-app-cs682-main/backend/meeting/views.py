from .models import Meeting
from rest_framework import generics, viewsets, status
from rest_framework.response import Response
from rest_framework.decorators import api_view
from .serializers import MeetingSerializer

@api_view(['GET', 'POST'])
def schedule(request):
    if request.method == 'GET':
        queryset = Meeting.objects.all()
        serialized_queryset = [MeetingSerializer(member).data for member in queryset if not member.deleted]
        return Response(serialized_queryset, status=status.HTTP_200_OK)
    elif request.method == 'POST':
        serializer = MeetingSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'message': 'Meeting created.'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
def ocr(request):
    # Currently just returning text
    data_dict = request.data['image_binary']
    int_list = []
    for i in range(len(data_dict)):
        int_list.append(int(data_dict[str(i)]))
    gv_api_response = _handwriting_to_text(bytes(int_list))
    return Response({'text': gv_api_response.full_text_annotation.text}, status=status.HTTP_200_OK)

@api_view(['PUT'])
def edit_meeting(request, pk):
    meeting = Meeting.objects.get(id=pk)
    serializer = MeetingSerializer(meeting, data=request.data, partial=True)
    if serializer.is_valid():
        serializer.save()
        return Response({'message': "Meeting edited."}, status=status.HTTP_200_OK)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

def _handwriting_to_text(image_data):
    """
    Pulled/adapted from Google Vision docs.
    Detect handwriting in image and return
    OCR details, including text transcription.
    """

    # This import is in function scope moreso for development/human reasons than
    # for production/execution reasons. While some interesting discussion is
    # available on the pros/cons of function scope imports, the author's chief
    # concerns are 1) avoiding annoying errors if other developers choose not to
    # install this package, and 2) making it virtually impossible to forget to
    # remove the import if a future developer changes the OCR API.
    from google.cloud import vision

    client = vision.ImageAnnotatorClient()

    image = vision.Image(content=image_data)

    response = client.document_text_detection(image=image)

    for page in response.full_text_annotation.pages:
        for block in page.blocks:
            print(f"\nBlock confidence: {block.confidence}\n")

            for paragraph in block.paragraphs:
                print("Paragraph confidence: {}".format(paragraph.confidence))

                for word in paragraph.words:
                    word_text = "".join([symbol.text for symbol in word.symbols])
                    print(
                        "Word text: {} (confidence: {})".format(
                            word_text, word.confidence
                        )
                    )

                    for symbol in word.symbols:
                        print(
                            "\tSymbol: {} (confidence: {})".format(
                                symbol.text, symbol.confidence
                            )
                        )

    if response.error.message:
        raise Exception(
            "{}\nFor more info on error messages, check: "
            "https://cloud.google.com/apis/design/errors".format(response.error.message)
        )

    return response

