from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import MeetingViewSet

router = DefaultRouter()
router.register(r'meeting', MeetingViewSet)
# URLs for the meeting app.
urlpatterns = [
    # - '' (empty string): Root endpoint for the meeting app.
    # Endpoint for CRUD operations on meeting objects.
    path('', include(router.urls)),
]
