from rest_framework import generics, viewsets
from .models import Meeting
from .serializers import MeetingSerializer
# ViewSet for interacting with Meeting objects.
class MeetingViewSet(viewsets.ModelViewSet):
    # The queryset of all Meeting objects.
    queryset = Meeting.objects.all()
    # The serializer class used for Meeting serialization.
    serializer_class = MeetingSerializer
