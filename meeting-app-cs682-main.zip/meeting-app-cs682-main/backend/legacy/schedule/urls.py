from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import ScheduleViewSet

router = DefaultRouter()
router.register(r'schedule', ScheduleViewSet)
# URLs for the schedule app.
# 'schedule/': Endpoint for CRUD operations on schedule objects.
urlpatterns = [
    path('', include(router.urls)),
]
