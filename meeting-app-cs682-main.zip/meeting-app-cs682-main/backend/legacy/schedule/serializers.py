from rest_framework import serializers
from .models import Schedule
# Serializer class for the Schedule model.
class ScheduleSerializer(serializers.ModelSerializer):
    # Specifies the metadata for the serializer, including the model and fields to include.
    class Meta:
        model = Schedule
        fields = '__all__'
