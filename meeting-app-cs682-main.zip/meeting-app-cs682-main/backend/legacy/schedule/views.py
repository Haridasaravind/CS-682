from rest_framework import viewsets
from .models import  Schedule
from .serializers import ScheduleSerializer
# ViewSet for interacting with Schedule objects.
class ScheduleViewSet(viewsets.ModelViewSet):
    # The queryset of all Schedule objects.
    queryset = Schedule.objects.all()
    # The serializer class used for Schedule serialization.
    serializer_class = ScheduleSerializer
