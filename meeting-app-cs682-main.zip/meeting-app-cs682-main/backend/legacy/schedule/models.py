from django.db import models
# Represents a scheduled meeting.
class Schedule(models.Model):
    # The primary key for the meeting.
    meeting_id = models.AutoField(primary_key=True),
    # The name of the meeting.
    meeting_name = models.CharField(max_length=255),
    # The type or category of the meeting.
    meeting_type = models.CharField(max_length=255),
    # The date of the meeting.
    meeting_date = models.DateField(),
    # The time of the meeting.
    meeting_time = models.TimeField(),
    # The duration of the meeting.
    meeting_duration = models.CharField(max_length=255),
    # A field to store the list of attendees.
    meeting_attendees = models.TextField(),
    # Additional notes or details about the meeting
    meeting_notes = models.TextField(),
    # Indicates if the meeting has been deleted.
    meeting_deleted = models.BooleanField(),
