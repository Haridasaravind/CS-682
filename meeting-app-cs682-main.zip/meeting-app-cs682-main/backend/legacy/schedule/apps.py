from django.apps import AppConfig

# Configuration class for the 'schedule' app.
class ScheduleConfig(AppConfig):
    # The default auto-generated field used for model primary keys.
    default_auto_field = 'django.db.models.BigAutoField'
    # the name of thje Django app.
    name = 'schedule'
