from rest_framework import viewsets
from .models import  Scheduler
from .serializers import SchedulerSerializer

# ViewSet for interacting with Scheduler objects.
class SchedulerViewSet(viewsets.ModelViewSet):
    # The queryset of all Scheduler objects.
    queryset = Scheduler.objects.all()
    # The serializer class used for Scheduler serialization.
    serializer_class = SchedulerSerializer
