from django.db import models
# Represents a scheduled meeting in the scheduler.
class Scheduler(models.Model):
    # The primary key for the meeting.
    Meeting_id = models.AutoField(primary_key=True),
    # The name of the meeting.
    Meeting_name = models.CharField(max_length=256),
    # The type or category of the meeting.
    Meeting_type = models.CharField(max_length=256),
    # The date of the meeting.
    Meeting_date = models.DateField(),
    # The time of the meeting.
    Meeting_time = models.TimeField(),
    # The duration of the meeting.
    Meeting_duration = models.CharField(max_length=256),
    # A field to store the list of attendees.
    Meeting_attendees = models.TextField(),
    # Additional notes or details about the meeting.
    Meeting_notes = models.TextField(),
    # Indicates if the meeting has been deleted.
    Meeting_deleted = models.BooleanField(),
