from rest_framework import serializers
from .models import Scheduler

# Serializer class for the Scheduler model.
class SchedulerSerializer(serializers.ModelSerializer):
    # Specifies the metadata for the serializer, including the model and fields to include.
    class Meta:
        model = Scheduler
        fields = '__all__'
