/**
 * This component is contains the meeting table in the application. It contains a table for list of meeting.
 * 
 * @params: {props}
 * 
 * 
 */

import React, {useState, useEffect} from "react";
import { DataGrid } from "@mui/x-data-grid";
import { Button } from "reactstrap";
import IconButton from '@mui/material/IconButton';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import InfoIcon from '@mui/icons-material/Info';
import MeetingDetailsModal from "../../../components/modals/MeetingDetailsModal";
import meeting from "../../../demo-data/MeetingData";
import DeleteMeetingModal from "../../../components/modals/DeleteMeetingModal";
import EditMeetingModal from "../../../components/modals/EditMeetingModal";

const Meetingtable = (props) =>  {

// const [filteredArray, setFilteredArray] = useEffect();
const [isInformationModalOpen, setIsInformationModalOpen] = useState(false);
const [isDeleteMeetingModalOpen, setIsDeleteMeetingModalOpen] = useState(false);
const [isEditMeetingModalOpen, setIsEditMeetingModalOpen] = useState(false);
const [id, setId] = useState();

const data2 = props.data; 
const columns = [
  // { field: 'id', headerName: 'ID', width: 70 },
  { field: "name", headerName: "Title", width: 200 },
  { field: "type", headerName: "Type", width: 180 },
  { field: "date", headerName: "Date", width: 180 },
  { field: "time", headerName: "Time", width: 180 },
  { field: "duration", headerName: "Duration", width: 180 },
  {field: 'notes',
  headerName: 'Details',
  sortable: false,
  width: 120,
  disableClickEventBubbling: true,
  renderCell: (params) => {
  //   return null;

  const onInfoIcon = () => {
      // setTaskId(params.id);
      toggleInformationModal();
    };
    
    return (
      // <GridActionsCellItem>\
      <div>
        <IconButton>
          <InfoIcon onClick={onInfoIcon}/>
        </IconButton>
        </div>
      // </GridActionsCellItem>
    );
  },
},
  {field: 'actions',
  headerName: 'Actions',
  sortable: false,
  width: 120,
  disableClickEventBubbling: true,
  renderCell: (params) => {
    const onClick = () => {
      // console.log(`Editing row ${params.id}`);
      setId(params.id);
      console.log(id);
      toggleDeleteMeetingModal();
    };

    const onEditToggle = () => {
      // console.log(`Editing row ${params.id}`);
      setId(params.id);
      console.log(id);
      toggleEditMeetingModal();
    };
  //   return null;
    return (
      // <GridActionsCellItem>\
      <div>
        <IconButton>
          <EditIcon  onClick={onEditToggle}/>
        </IconButton>
        <IconButton>
          <DeleteIcon onClick={onClick}/>
        </IconButton>
        </div>
      // </GridActionsCellItem>
    );
  },
},
];

const detail = () => {
  return;
  <Button>Details</Button>;
};

const toggleDeleteMeetingModal = () => {
  setIsDeleteMeetingModalOpen(!isDeleteMeetingModalOpen);
};

const toggleInformationModal = () => {
  setIsInformationModalOpen(!isInformationModalOpen);
};

const toggleEditMeetingModal = () => {
  setIsEditMeetingModalOpen(!isEditMeetingModalOpen);
};


// const newArray = (!Array.isArray(props.data) || props.data.length === 0) ? data2.filter(el => el.deleted === false) : data2;
const test = () => {
  console.log(props.data);
}

if (!props.data) {
  return <div onClick = {test}>Loading...</div>;
}
  return (
    <div style={{ height: 400, width: "100%" }}>
      {isDeleteMeetingModalOpen ? <DeleteMeetingModal isOpen={isDeleteMeetingModalOpen} toggle={toggleDeleteMeetingModal} index={id}/> : <></>}
      {isInformationModalOpen ? <MeetingDetailsModal isOpen={isInformationModalOpen} toggle={toggleInformationModal} index={id}/> : <></>}
      {isEditMeetingModalOpen ? <EditMeetingModal isOpen={isEditMeetingModalOpen} toggle={toggleEditMeetingModal} index={id}/> : <></>}
      <DataGrid
        rows={data2}
        columns={columns}
        pageSize={5}
        rowsPerPageOptions={[5]}
        checkboxSelection
      />
    </div>
  );
}

export default Meetingtable;