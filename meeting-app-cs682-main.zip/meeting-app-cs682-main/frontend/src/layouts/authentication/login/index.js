/**
 * This component is the landing page of the application. It contains a form which is used to login a user.
 * 
 * @params: {props}
 * 
 * 
 */

import React, { useState } from "react";
import {
  Card,
  CardHeader,
  CardBody,
  Button,
  Form,
  FormGroup,
  Label,
  Input,
  Container,
  Row,
  Col,
} from "reactstrap";
import { useNavigate } from "react-router-dom";
import { FaUserAlt, FaLock } from "react-icons/fa";
import { login } from "../../../api";
import "bootstrap/dist/css/bootstrap.min.css";

function Login(props) {
  const navigate = useNavigate();

  const handleSignUp = () => {
    navigate("/signup");
  };

  const history = useNavigate();
  const [formData, setFormData] = useState({
    username: "",
    password: "",
    errors: {
      username: "",
      password: "",
    },
  });
  
  const [error, setError] = useState(null);
  const handleChange = (event) => {
  const { name, value } = event.target;

  setFormData((prevState) => ({
    ...prevState,
    [name]: value,
    errors: {
      ...prevState.errors,
      [name]: "",
    },
  }));
};

  const validateForm = () => {
    const { username, password } = formData;
    const errors = {};
  
    // Check for errors and update the errors object accordingly
    if (!username) {
      errors.username = "Username is required.";
    }
  
    if (!password) {
      errors.password = "Password is required.";
    }
  
    return errors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    
    const errors = validateForm();
    if (Object.keys(errors).length > 0) {
      setFormData((prevState) => ({
        ...prevState,
        errors: { ...errors },
      }));
      return;
    }
  
    login(formData)
      .then(() => {
        navigate('/dashboard');
        // props.setAuthenticate(true);
      })
      .catch((error) => {
        console.log(error);
        setError(error.response.data);
      });
  };
  
  return (
    <div className="bgImage d-flex align-items-center justify-content-center">
      <Card className="vertical-card card-with-background">
        <CardHeader className="page-header text-center card-head">Sign in</CardHeader>
        <CardBody className="card-body">
          <Form onSubmit={handleSubmit}>
            <FormGroup>
              <Label for="username" className="mb-1">
                Username
              </Label>
              {/* <FaUserAlt className="mr-2" /> */}
              <Input
                type="text"
                id="username"
                name="username"
                value={formData.username}
                onChange={handleChange}
                placeholder="Enter your username"
                invalid={!!formData.errors.username}
              />
              {formData.errors.username && <div className="invalid-feedback">{formData.errors.username}</div>}
            </FormGroup>
            <FormGroup>
              <Label for="password" className="mb-1">
                {/* <FaLock className="mr-2" />  */}
                Password
              </Label>
              <Input
                type="password"
                id="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                placeholder="Enter your password"
                invalid={!!formData.errors.password}
              />
              {formData.errors.password && <div className="invalid-feedback">{formData.errors.password}</div>}
              <div className="text-right mt-2">
                <a className="link-text" href="/forgot-password">
                  Forgot password?
                </a>
              </div>
            </FormGroup>
            <Button type="submit" color="primary" block className="mt-4">
              Sign in
            </Button>
          </Form>
          <Button color="light" block className="mt-4" onClick={handleSignUp}>
            Sign up
          </Button>
        </CardBody>
      </Card>
    </div>
  );
}

export default Login;
