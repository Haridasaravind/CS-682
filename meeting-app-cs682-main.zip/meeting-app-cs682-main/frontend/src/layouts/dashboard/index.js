/**
 * This component is the dashboard page of the application. It contains 8 different components.
 * 1. Header
 * 2. High priority task table
 * 3. Piechart to show task in progress
 * 4. Card containing current data and upcoming meeting
 * 5. Mini card containing active tasks
 * 6. Mini card containing task due this week
 * 7. Mini card containing upcoming meeting
 * 8. Footer
 * 
 * @params: {props}
 * 
 * 
 */

import React, { useEffect, useState } from "react";
import {
  Container,
  Row,
  Col,
  Card,
  CardTitle,
  CardText,
  Nav,
  NavLink,
} from "reactstrap";
import CircularProgress from '@mui/material/CircularProgress';
import { PieChart, pieChartDefaultProps } from "react-minimal-pie-chart";
import { Button } from "reactstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import DataTable from "./components/DataTable";
import { useNavigate } from "react-router-dom";
import { logout, meeting_view, tasks_view } from "../../api";
import DateAndTodoList from "./components/DateAndTodoList";
import TaskTable from "../taskAssignment/component/TaskTable";
import Header from "../../components/header";
import { ArrowDownward } from '@mui/icons-material';
// import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
// import { Pie } from 'react-chartjs-2';

const Dashboard = () => {
  const navigate = useNavigate();
  const [tasks, getTasks] = useState("");
  const [meeting, getMeeting] = useState("");
  const [activeTasks, setActiveTasks] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [isLoading2, setIsLoading2] = useState(true);
  const [showButton, setShowButton] = useState(true);
  const defaultLabelStyle = {
    fontSize: "5px",
    fontFamily: "sans-serif",
  };

  useEffect(() => {
    const viewAllTasks = async () => {
      console.log("Yeah its here");
      await tasks_view()
        .then((req) => {
          const task = req.data.results;
          getTasks(task);
          setActiveTasks(task.length);
          console.log(tasks);
          console.log(tasks.length);
          setIsLoading(false);
        })
        .catch((error) => {
          console.log(error);
        });
    };
    const viewAllMeeting = async () => {
      console.log("Yeah its here");
      await meeting_view()
        .then((req) => {
          const meeting = req.data.results;
          getMeeting(meeting);
          // setActiveTasks(meeting.length);
          console.log(tasks);
          console.log(tasks.length);
          setIsLoading2(false);
        })
        .catch((error) => {
          console.log(error);
        });
    };
  const timeout = setTimeout(() => {
    viewAllMeeting();
    viewAllTasks();
  }, 1000);
  
  return () => clearTimeout(timeout);
  }, []);

  var completed = Array.isArray(tasks) ? tasks.filter(function (el) {
    return el.is_completed === true;
  }) : [];

  var inProgress = Array.isArray(tasks) ? tasks.filter(function (el) {
    var current_date = new Date();
    var task_date = new Date(el.start_date);
    return task_date <= current_date;
}) : [];

var meetingProgress = Array.isArray(meeting) ? meeting.filter(function (el) {
  var current_date = new Date();
  var task_date = new Date(el.date);
  return task_date >= current_date;
}) : [];

var notYetStarted = Array.isArray(tasks) ? tasks.filter(function (el) {
  var current_date = new Date();
  var task_date = new Date(el.start_date);
  return task_date >= current_date;
}) : [];

  var completed_length = completed === NaN ? 0 : completed.length ;

  var inProgress_length = inProgress === NaN ? 0 : inProgress.length ;

  var meetingProgress_length = meetingProgress === NaN ? 0 : meetingProgress.length ;

  var notYetStarted_length = notYetStarted === NaN ? 0 : notYetStarted.length ;

  const shiftSize = 7;

  const handleLogout = async () => {
    logout()
      .then(() => {
        navigate("/");
      })
      .catch((error) => {
        console.log(error.response.data);
      });
  };

  const scrollToBottom = () => {
    window.scrollTo({
      top: document.documentElement.scrollHeight,
      behavior: 'smooth'
    });
    setShowButton(false);
  };

  return (
    <div className="bgImage">
{isLoading ? <CircularProgress className="circular-progress" /> :      
      <main>
      <Header />
      {showButton && (<Button className="scrollButton" color="primary" onClick={scrollToBottom}><ArrowDownward /></Button>)}
        <Container className="my-4">
          <Row className="fixed-height-dashboard-upper-cards">
            <Col md={6}>

            <Card className="my-card my-card-height">
                <CardTitle tag="h5" className="card-head p-3">
                  High Priority tasks
                </CardTitle>
                <CardText className="p-3 card-body">
                {isLoading ? <CircularProgress /> : <TaskTable rows={tasks} dashboard={true}/>}
                </CardText>
              </Card>

            </Col>
            <Col md={4}>
            
            <Card className="my-card pie-chart-progress">
                <CardTitle tag="h5" className="p-3 card-head">
                  Progress Chart
                </CardTitle>
                <CardText className="p-3 card-body">
                  <PieChart
                    data={[
                      { title: "Completed", value: completed_length, color: "#E38627" },
                      { title: "In Progress", value: inProgress_length, color: "#C13C37" },
                      { title: "Not yet Started", value: notYetStarted_length, color: "#6A2135" },
                    ]}
                    radius={pieChartDefaultProps.radius - shiftSize}
                    segmentsShift={(index) => (index === 0 ? shiftSize : 0.5)}
                    label={({ dataEntry }) => dataEntry.value}
                    style={{ height: "200px" }}
                    labelStyle={{ ...defaultLabelStyle }}
                  />
                </CardText>
              </Card>

              <Card className="my-card">
                <CardText className="p-3 card-body">
                {isLoading2 ? <CircularProgress /> :<DateAndTodoList data={meetingProgress[0]}/>}
                </CardText>
              </Card>

            </Col>
            <Col md={2}>

              <Card className="my-card middle-order-card">
                  <CardTitle tag="h5" className="p-3 card-head-small">
                  Active Tasks
                  </CardTitle>
                  <CardText className="p-3 card-text-number card-body">{tasks.length}</CardText>
                </Card>

              <Card className="my-card middle-order-card">
                  <CardTitle tag="h5" className="p-3 card-head-small">
                  Tasks due this week
                  </CardTitle>
                  <CardText className="p-3 card-text-number card-body">5</CardText>
                </Card>

              <Card className="my-card middle-order-card">
                  <CardTitle tag="h5" className="p-3 card-head-small">
                  Upcoming Meetings
                  </CardTitle>
                  {isLoading2 ? <CircularProgress /> : <CardText className="p-3 card-text-number card-body">{meetingProgress_length}</CardText>}
                </Card>

            </Col>
          </Row>
        </Container>
        <footer className="bg-dark py-3">
        <Container>
          <p className="text-white text-center">Copyright © 2023</p>
        </Container>
      </footer>
      </main>}
    </div>
  );
};

export default Dashboard;
