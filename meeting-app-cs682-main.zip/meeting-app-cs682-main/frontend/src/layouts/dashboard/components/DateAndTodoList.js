import React, { useState } from 'react';
import CircularProgress from '@mui/material/CircularProgress';

const DateAndTodoList = (props) => {
  const [todos, setTodos] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  const meetingArray = props.data;

  const handleAddTodo = (e) => {
    console.log(meetingArray[0].name);
  };

  const handleDeleteTodo = (index) => {
    // console.log(meetingArray);
  };

  

  const date = new Date();
  const month = date.toLocaleString('default', { month: 'long' });
  const day = date.getDate();
  const year = date.getFullYear();

  return (
    <div className="date-and-todo-list">
      <div className="date">
        <h1>{month}</h1>
        <h2>{day}</h2>
        <h3>{year}</h3>
      </div>
      <div className="todo-list">
        <h4 onClick={handleAddTodo}>Upcoming Meeting</h4>
          <p>
            {/* {meetingArray[0].name} */}
            Meeting 1
        </p>
      </div>
    </div>
  );
};

export default DateAndTodoList;
