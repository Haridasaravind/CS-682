import React, {useEffect, useState} from "react";
import {
  Container,
  Card,
  CardTitle,
  CardText,
  Row,
  Col,
  Button
} from "reactstrap";
import CircularProgress from '@mui/material/CircularProgress';
import "bootstrap/dist/css/bootstrap.min.css";
import { meeting_view } from "../../api";
import Header from "../../components/header";
import CreateMeetingModal from "../../components/modals/CreateMeetingModal";
import MeetingCard from "./components/MeetingCard";

/**
 * "Schedule" page of application displays meetings.
 */
const Schedule = () => {
  const [meetings, setMeetings] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [isCreateMeetingModalOpen, setIsCreateMeetingModalOpen] = useState(false);
  /*
   * mustGetMeetings is a boolean useEffect() trigger - useful to
   * have a single trigger for the API call to avoid filling
   * useEffect's dependency array with booleans and complicating
   * its execution conditional.
   */
  const [mustGetMeetings, setMustGetMeetings] = useState(true);

  const toggleCreateMeetingModal = () => {
    setIsCreateMeetingModalOpen(!isCreateMeetingModalOpen);
    setMustGetMeetings(!mustGetMeetings);
  };

  useEffect(() => {
    const fetchMeetings = async () => {
      const response =
        await meeting_view()
        .catch((error) => {
          console.log(error)
        });
      setMeetings(response.data);
      setIsLoading(false);
    }

    if (mustGetMeetings) {
      fetchMeetings();
    }
  }, [mustGetMeetings]);


  console.log(meetings);

  return (
    <div className="bgImage">
      <Header />
      <main>
        <Container className="my-4">
          <Card className="my-card schedule-card">
            <CardTitle tag="h5" className="p-3 card-head">
              <Row>
                <Button
                  className="new-meeting-button"
                  onClick={toggleCreateMeetingModal}
                >
                  New Meeting
                </Button>
                <CreateMeetingModal
                   isOpen={isCreateMeetingModalOpen}
                   toggle={toggleCreateMeetingModal}
                />
              </Row>
            </CardTitle>
            <CardText className="p-3 schedule-card-body">
              {
                isLoading ?
                <CircularProgress /> :
                <Row>
                  {
                    meetings.map(
                      (meeting) => (
                        <Col key={meeting.id} xs={12} md={4} lg={3}>
                          <MeetingCard
                            meeting={meeting}
                            mustGetMeetings={mustGetMeetings}
                            setMustGetMeetings={setMustGetMeetings}
                          />
                        </Col>
                      )
                    )
                  }
                </Row>
              }
            </CardText>
          </Card>
        </Container>
      </main>
      <footer className="bg-dark py-3">
        <Container>
          <p className="text-white text-center">Copyright © 2023</p>
        </Container>
      </footer>
    </div>
  );
};

export default Schedule;

