import {
  React,
  useState
} from "react";
import {
  Card,
  CardTitle,
  CardText,
  CardBody,
} from "reactstrap";
import IconButton from '@mui/material/IconButton';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import MeetingDetailsModal from "../../../components/modals/MeetingDetailsModal";
import EditMeetingModal from "../../../components/modals/EditMeetingModal";
import DeleteMeetingModal from "../../../components/modals/DeleteMeetingModal";

/*
 * MeetingCard for displaying key details of a meeting -
 * "Schedule" page displays MeetingCards.
 */
const MeetingCard = (props) => {

  const [showIconButtons, setShowIconButtons] = useState(false);
  const [isMeetingDetailsModalOpen, setIsMeetingDetailsModalOpen] = useState(false);
  const [isEditMeetingModalOpen, setIsEditMeetingModalOpen] = useState(false);
  const [isDeleteMeetingModalOpen, setIsDeleteMeetingModalOpen] = useState(false);

  const toggleMeetingDetailsModal = () => {
    setShowIconButtons(false);
    setIsMeetingDetailsModalOpen(!isMeetingDetailsModalOpen);
  };

  const toggleEditMeetingModal = () => {
    setShowIconButtons(false);
    setIsMeetingDetailsModalOpen(false);
    setIsEditMeetingModalOpen(!isEditMeetingModalOpen);
    props.setMustGetMeetings(!props.mustGetMeetings);
  };

  const toggleDeleteMeetingModal = () => {
    setShowIconButtons(false);
    setIsMeetingDetailsModalOpen(false);
    setIsDeleteMeetingModalOpen(!isDeleteMeetingModalOpen);
    props.setMustGetMeetings(!props.mustGetMeetings);
  };

  const onCardClick = () => {
    toggleMeetingDetailsModal();
  }

  const onEditClick = () => {
    toggleEditMeetingModal();
  };

  const onDeleteClick = () => {
    toggleDeleteMeetingModal();
  };



  return (
    <
      Card className="meeting-card"
      onClick = {onCardClick}
      onMouseEnter = {() => setShowIconButtons(true)}
      onMouseLeave = {() => setShowIconButtons(false)}
    >
      <
        MeetingDetailsModal
        meeting = {props.meeting}
        isOpen={
          isMeetingDetailsModalOpen &&
          !isEditMeetingModalOpen &&
          !isDeleteMeetingModalOpen
        }
        toggle={toggleMeetingDetailsModal}
      />
      <
        EditMeetingModal
        meeting = {props.meeting}
        isOpen={isEditMeetingModalOpen}
        toggle={toggleEditMeetingModal}
      />
      <
        DeleteMeetingModal
        meeting = {props.meeting}
        isOpen={isDeleteMeetingModalOpen}
        toggle={toggleDeleteMeetingModal}
      />
      <CardBody>
        <CardTitle>
          {props.meeting.name}
        </CardTitle>
        <CardText>
          {
            showIconButtons &&
            <div>
              <IconButton style={{float:'left'}} size="small" onClick={onEditClick}>
                <EditIcon />
              </IconButton>
              <IconButton style={{float:'right'}} size="small" onClick={onDeleteClick}>
                <DeleteIcon/>
              </IconButton>
            </div>
          }
          {props.meeting.date}
          <br />
          {props.meeting.time}
        </CardText>
      </CardBody>
    </Card>
  )
}

export default MeetingCard;

