/**
 * This component is the Edit meeting modal of the application. It contains form to edit a meeting.
 *
 * @params: {props}
 *
 *
 */

import {
  React,
  useState,
  useEffect
} from "react";
import {
  Button,
  Form,
  FormGroup,
  Label,
  Input,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
} from "reactstrap";
import { FormFeedback } from "reactstrap";
import { meeting_update } from "../../api";

const EditMeetingModal = (props) => {

  const [formData, setFormData] = useState({
    id: '',
    name: '',
    type: '',
    date: '',
    time: '',
    duration: '',
    attendees: '',
    notes: ''
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: value
    }));
    setErrors((prevErrors) => ({
      ...prevErrors,
      [name]: '' // Clear any previous error for the changed input
    }));
  };

  useEffect(() => {
    viewSingleMeeting();
  // eslint-disable-next-line
  }, []);

  const viewSingleMeeting = () => {
    setFormData({
      id: props.meeting.id,
      name: props.meeting.name,
      type: props.meeting.type,
      date: props.meeting.date,
      time: props.meeting.time,
      duration: props.meeting.duration,
      attendees: props.meeting.attendees,
      notes: props.meeting.notes,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const response = await meeting_update(formData.id, formData)
      .catch((error) => {
        console.error("Error updating meeting:", error);
      })
    console.log(response.data.message);
    props.toggle();
  };

  return (
    <Modal isOpen={props.isOpen} toggle={props.toggle}>
      <ModalHeader>Edit Meeting</ModalHeader>
      <Form onSubmit={handleSubmit}>
        <ModalBody>
      <FormGroup>
        <Label for="name">Name</Label>
        <Input
          type="text"
          name="name"
          id="name"
          placeholder="Enter name"
          value={formData.name}
          onChange={handleChange}
          invalid={errors.name}
        />
        {errors.name && <FormFeedback>{errors.name}</FormFeedback>}
      </FormGroup>
      <FormGroup>
        <Label for="type">Type</Label>
        <Input
          type="text"
          name="type"
          id="type"
          placeholder="Enter type"
          value={formData.type}
          onChange={handleChange}
          invalid={errors.type}
        />
        {errors.type && <FormFeedback>{errors.type}</FormFeedback>}
      </FormGroup>
      <FormGroup>
        <Label for="date">Date</Label>
        <Input
          type="date"
          name="date"
          id="date"
          placeholder="Enter date"
          value={formData.date}
          onChange={handleChange}
          invalid={errors.date}
        />
        {errors.date && <FormFeedback>{errors.date}</FormFeedback>}
      </FormGroup>
      <FormGroup>
        <Label for="time">Time</Label>
        <Input
          type="time"
          name="time"
          id="time"
          placeholder="Enter time"
          value={formData.time}
          onChange={handleChange}
          invalid={errors.time}
        />
        {errors.time && <FormFeedback>{errors.time}</FormFeedback>}
      </FormGroup>
      <FormGroup>
        <Label for="duration">Duration</Label>
        <Input
          type="text"
          name="duration"
          id="duration"
          placeholder="Enter duration"
          value={formData.duration}
          onChange={handleChange}
          invalid={errors.duration}
        />
        {errors.duration && <FormFeedback>{errors.duration}</FormFeedback>}
        </FormGroup>
      <FormGroup>
        <Label for="duration">attendees</Label>
        <Input
          type="text"
          name="attendees"
          id="attendees"
          placeholder="Enter attendees"
          value={formData.attendees}
          onChange={handleChange}
          invalid={errors.attendees}
        />
        {errors.attendees && <FormFeedback>{errors.attendees}</FormFeedback>}
        </FormGroup>
      <FormGroup>
        <Label for="duration">Notes</Label>
        <Input
          type="text"
          name="notes"
          id="notes"
          placeholder="Enter notes"
          value={formData.notes}
          onChange={handleChange}
          invalid={errors.notes}
        />
        {errors.notes && <FormFeedback>{errors.notes}</FormFeedback>}
        </FormGroup>
        </ModalBody>
        <ModalFooter>
          <Button color="primary" type="submit">
            Save Meeting
          </Button>{" "}
          <Button color="secondary" onClick={props.toggle}>
            Cancel
          </Button>
        </ModalFooter>
      </Form>
    </Modal>
  );
};

export default EditMeetingModal;
