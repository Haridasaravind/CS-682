/**
 * This component is the Create meeting modal of the application. It contains form to create a meeting.
 *
 * @params: {props}
 *
 *
 */

import {
  React,
  useState,
  useRef
} from 'react';
import {
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Form,
  FormGroup,
  Label,
  Input,
  Button
} from 'reactstrap';
import ReactCrop from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';
import {
  meeting_create,
  meeting_ocr
} from '../../api';

const CreateMeetingModal = (props) => {
  const [name, setName] = useState('');
  const [type, setType] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [duration, setDuration] = useState('');
  const [attendees, setAttendees] = useState('');
  const [notes, setNotes] = useState('');
  const [imageSrc, setImageSrc] = useState('');
  const [crop, setCrop] = useState({
    unit: '%', // Can be 'px' or '%'
    x: 25,
    y: 25,
    width: 50,
    height: 50
  })
  /*
   * "First" scan state means ready to select an image. When not in
   * first scanstate, we are in "second" scan state, meaning ready to
   * either send OCR request or cancel (go back to first state).
   */
  const [isInFirstScanState, setIsInFirstScanState] = useState(true);
  const imageRef = useRef(null);

  const handleNameChange = (e) => setName(e.target.value);
  const handleTypeChange = (e) => setType(e.target.value);
  const handleDateChange = (e) => setDate(e.target.value);
  const handleTimeChange = (e) => setTime(e.target.value);
  const handleDurationChange = (e) => setDuration(e.target.value);
  const handleAttendeesChange = (e) => setAttendees(e.target.value);
  const handleNotesChange = (e) => setNotes(e.target.value);

  const handleSubmit = (e) => {
    e.preventDefault();
    const newMeeting = {
       name:name,
       type:type,
       date:date,
       time:time,
       duration:duration,
       attendees:attendees,
       notes:notes,
      };

    // Send the form data to the API using fetch or axios
    meeting_create(newMeeting)
      .then((data) => {
      })
      .catch((error) => {
        console.error("Error creating meeting:", error);
      });
    console.log(newMeeting);
    props.toggle();
  };

  const onImageChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = () => {
        setImageSrc(reader.result);
      }
      reader.readAsDataURL(e.target.files[0]);
    }
  }

  const handleScanFromPhotoClick = async () => {
    imageRef.current.click();
    toggleScanState();
  }

  /*
   * Get binary array representation of cropped image then
   * send POST request to meeting view that makes call to
   * OCR api. Currently logs response text in console.
   */
  const handleOCRRequest = () => {
    const imgElem = document.getElementById("img-elem")
    const croppedImageCanvas = document.createElement("canvas");
    croppedImageCanvas.width = 0.01 * crop.width * imgElem.naturalWidth;
    croppedImageCanvas.height = 0.01 * crop.height * imgElem.naturalHeight;
    const croppedImageContext = croppedImageCanvas.getContext("2d");

    croppedImageContext.drawImage(
      imgElem,
      0.01 * crop.x * imgElem.naturalWidth,
      0.01 * crop.y * imgElem.naturalHeight,
      0.01 * crop.width * imgElem.naturalWidth,
      0.01 * crop.height * imgElem.naturalHeight,
      0,
      0,
      0.01 * crop.width * imgElem.naturalWidth,
      0.01 * crop.height * imgElem.naturalHeight,
    );

    const croppedImage = new Promise(
      (resolve, reject) => {
        croppedImageCanvas.toBlob(
          blob => {resolve(blob);},
          'image/jpeg'
        );
      }
    );

    const reader = new FileReader();
    reader.onload = async () => {
      const response = await meeting_ocr({image_binary : new Uint8Array(reader.result)})
        .catch((error) => {
          console.log(error);
        });
      console.log(response.data.text);
    }
    croppedImage.then(res => reader.readAsArrayBuffer(res));
    toggleScanState();
  }

  /*
   * In first scan state (isInFirstScanState is true), display
   * "Scan Meeting From Photo" button. In second scan state
   * (isInFirstScanState is false), show "Process Image" and
   * "Cancel" buttongs.
   */
  const toggleScanState = () => {
    setIsInFirstScanState(!isInFirstScanState);
  }

  return (
    <Modal isOpen={props.isOpen} toggle={props.toggle}>
      <ModalHeader>New Meeting</ModalHeader>
      <ModalBody>
        <input type="file" hidden ref={imageRef} onChange={onImageChange} />
        {
          isInFirstScanState ?
            <div>
              <Button
                className="scan-from-photo-button"
                onClick={handleScanFromPhotoClick}
              >
                Scan Meeting from Photo
              </Button>
            </div>
            :
            <div>
              {!!imageSrc && (
                <ReactCrop crop={crop} onChange={(crop, percentCrop) => setCrop(percentCrop)}>
                  <img id="img-elem" src={imageSrc} alt="Crop me." />
                </ReactCrop>
              )}
              <Button
                className="process-image-button"
                onClick={handleOCRRequest}
              >
                Process Image
              </Button>{" "}
              <Button
                className="cancel-button"
                onClick={toggleScanState}
              >
                Cancel
              </Button>
            </div>
        }
        <Form onSubmit={handleSubmit}>
          <FormGroup>
            <Label for="name">Name</Label>
            <Input type="text" name="name" id="name" value={name} onChange={handleNameChange} required />
          </FormGroup>
          <FormGroup>
            <Label for="type">Type</Label>
            <Input type="text" name="type" id="type" value={type} onChange={handleTypeChange} required />
          </FormGroup>
          <FormGroup>
            <Label for="date">Date</Label>
            <Input type="date" name="date" id="date" value={date} onChange={handleDateChange} required />
          </FormGroup>
          <FormGroup>
            <Label for="time">Time</Label>
            <Input type="time" name="time" id="time" value={time} onChange={handleTimeChange} required />
          </FormGroup>
          <FormGroup>
            <Label for="duration">Duration</Label>
            <Input type="text" name="duration" id="duration" value={duration} onChange={handleDurationChange} required />
          </FormGroup>
          <FormGroup>
            <Label for="attendees">Attendees</Label>
            <Input type="text" name="attendees" id="attendees" value={attendees} onChange={handleAttendeesChange} required />
          </FormGroup>
          <FormGroup>
            <Label for="notes">Notes</Label>
            <Input type="textarea" name="notes" id="notes" value={notes} onChange={handleNotesChange} required />
          </FormGroup>
        </Form>
      </ModalBody>
      <ModalFooter>
        <Button color="primary" type="submit" onClick={handleSubmit}>Save</Button>{' '}
        <Button color="secondary" onClick={props.toggle}>Cancel</Button>
      </ModalFooter>
    </Modal>
  );
};

export default CreateMeetingModal;

