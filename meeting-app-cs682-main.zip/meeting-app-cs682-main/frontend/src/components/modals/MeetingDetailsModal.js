/**
 * This component is the meeting details modal of the application.
 *
 * @params: {props}
 *
 *
 */

import {
  React,
  // useState,
  // useEffect
} from "react";
import {
  // Button,
  Modal,
  ModalHeader,
  ModalBody,
  // ModalFooter,
} from "reactstrap";
//import CreateTaskModal from "./CreateTaskModal"

const MeetingDetailsModal = (props) => {
  //const [isCreateTaskModalOpen, setIsCreateTaskModalOpen] = useState(false);
  /*
  const toggleCreateTaskModal = () => {
    setIsCreateTaskModalOpen(!isCreateTaskModalOpen);
  };
  */

  return (
    <Modal isOpen={props.isOpen} toggle={props.toggle}>
      <ModalHeader toggle={props.toggle}>{props.meeting.name}</ModalHeader>
      <ModalBody>
        <h5>{props.meeting.date} at {props.meeting.time}</h5>
        <br />
        <h7>Type: {props.meeting.type}</h7>
        <br />
        <h7>Duration: {props.meeting.duration}</h7>
        <br />
        <h7>Attendees: {props.meeting.attendees}</h7>
        <br />
        <h7>Notes: {props.meeting.notes}</h7>
      </ModalBody>
      {
      /*
      **We may or may not do something with this here,**
      **but for now it's serving no purpose.**
      <ModalFooter>
        <CreateTaskModal
          isOpen={isCreateTaskModalOpen}
          toggle={toggleCreateTaskModal}
          <Button color="primary" onClick={toggleCreateTaskModal}>
            Task
          </Button>
        />
        <Button color="secondary" onClick={props.toggle}>
          Cancel
        </Button>
      </ModalFooter>
      */
      }
    </Modal>
  );
};

export default MeetingDetailsModal;

